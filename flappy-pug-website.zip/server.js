const http = require("http");
const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");

const root = __dirname;
const port = Number(process.env.PORT || 5174);
const host = process.env.HOST || "0.0.0.0";
const leaderboardFile = process.env.LEADERBOARD_FILE
  ? path.resolve(process.env.LEADERBOARD_FILE)
  : path.join(root, "leaderboard.json");
const types = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
};

function sendJson(res, status, value) {
  res.writeHead(status, { "Content-Type": types[".json"], "Cache-Control": "no-store" });
  res.end(JSON.stringify(value));
}

async function readLeaderboard() {
  try {
    const data = await fsp.readFile(leaderboardFile, "utf8");
    const scores = JSON.parse(data);
    return Array.isArray(scores) ? scores : [];
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
}

async function writeLeaderboard(scores) {
  await fsp.mkdir(path.dirname(leaderboardFile), { recursive: true });
  await fsp.writeFile(leaderboardFile, JSON.stringify(scores, null, 2));
}

function cleanUsername(value) {
  return String(value || "")
    .trim()
    .replace(/[^\w -]/g, "")
    .replace(/\s+/g, " ")
    .slice(0, 18);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 4096) {
        req.destroy();
        reject(new Error("Request body too large"));
      }
    });
    req.on("end", () => resolve(body));
    req.on("error", reject);
  });
}

http
  .createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

    if (url.pathname === "/api/leaderboard" && req.method === "GET") {
      const scores = await readLeaderboard();
      sendJson(res, 200, { scores: scores.slice(0, 10) });
      return;
    }

    if (url.pathname === "/api/score" && req.method === "POST") {
      try {
        const payload = JSON.parse(await readBody(req) || "{}");
        const username = cleanUsername(payload.username);
        const score = Number(payload.score);

        if (!username || !Number.isInteger(score) || score < 0 || score > 999999) {
          sendJson(res, 400, { error: "Invalid username or score" });
          return;
        }

        const scores = await readLeaderboard();
        const now = new Date().toISOString();
        const existing = scores.find((entry) => entry.username.toLowerCase() === username.toLowerCase());

        if (existing) {
          if (score > existing.score) {
            existing.username = username;
            existing.score = score;
            existing.updatedAt = now;
          }
        } else {
          scores.push({ username, score, updatedAt: now });
        }

        scores.sort((a, b) => b.score - a.score || a.username.localeCompare(b.username));
        const trimmed = scores.slice(0, 50);
        await writeLeaderboard(trimmed);
        sendJson(res, 200, { scores: trimmed.slice(0, 10) });
      } catch (error) {
        sendJson(res, 400, { error: "Could not save score" });
      }
      return;
    }

    if (req.method !== "GET" && req.method !== "HEAD") {
      res.writeHead(405);
      res.end("Method not allowed");
      return;
    }

    const requestPath =
      url.pathname === "/" || url.pathname === "/flappy-pug"
        ? "index.html"
        : decodeURIComponent(url.pathname);
    const file = path.resolve(root, requestPath.replace(/^\/+/, ""));

    if (!file.startsWith(root)) {
      res.writeHead(403);
      res.end("Forbidden");
      return;
    }

    fs.readFile(file, (error, data) => {
      if (error) {
        res.writeHead(404);
        res.end("Not found");
        return;
      }

      res.writeHead(200, { "Content-Type": types[path.extname(file)] || "application/octet-stream" });
      res.end(data);
    });
  })
  .listen(port, host, () => {
    console.log(`Flappy Pug running at http://127.0.0.1:${port}`);
  });
