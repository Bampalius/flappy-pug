# Flappy Pug

A small canvas game where a flying pug dodges colorful surfboards over sunset ocean waves, grabs treat bonuses, and submits scores to a leaderboard.

## Play

Open `index.html` in a browser, or run:

```powershell
node server.js
```

Then visit:

```text
http://127.0.0.1:5174
```

## Public Website

This is now a Node website. The easiest public deployment path is Render.

1. Put this folder in a GitHub repo.
2. Go to Render and create a new Blueprint from that repo.
3. Render will read `render.yaml` and create a web service named `flappy-pug`.
4. After the deploy finishes, Render gives you a public URL.

Use:

```text
npm start
```

The server reads `PORT` automatically on hosting platforms. It stores leaderboard scores in `leaderboard.json` by default. On a public host, use persistent storage and set `LEADERBOARD_FILE` to a file path on that disk, such as `/var/data/leaderboard.json`.

## Controls

- `Space`, `ArrowUp`, click, or tap: flap
- `P`: pause or resume
- `R`: restart
