const canvas = document.querySelector("#game");
const ctx = canvas.getContext("2d");
const scoreEl = document.querySelector("#score");
const bestEl = document.querySelector("#best");
const overlay = document.querySelector("#overlay");
const messageEl = document.querySelector("#message");
const startBtn = document.querySelector("#startBtn");
const pauseBtn = document.querySelector("#pauseBtn");
const restartBtn = document.querySelector("#restartBtn");
const playerForm = document.querySelector("#playerForm");
const usernameInput = document.querySelector("#username");
const playerStatus = document.querySelector("#playerStatus");
const leaderboardEl = document.querySelector("#leaderboard");
const refreshBoardBtn = document.querySelector("#refreshBoard");

const W = canvas.width;
const H = canvas.height;
const groundH = 92;
const storageKey = "flappy-pug-best";
const usernameKey = "flappy-pug-username";

let best = Number(localStorage.getItem(storageKey) || 0);
let playerName = localStorage.getItem(usernameKey) || "";
let score = 0;
let state = "ready";
let lastTime = 0;
let spawnTimer = 0;
let frameTime = 0;
let runTime = 0;
let pipes = [];
let clouds = [];
let snacks = [];
let pawBursts = [];

const pug = {
  x: 128,
  y: 310,
  r: 23,
  vy: 0,
  rotation: 0,
};

const physics = {
  gravity: 1540,
  flap: -500,
  pipeSpeed: 178,
  pipeGap: 202,
  pipeWidth: 78,
};

const surfboardPalettes = [
  { main: "#ff5f6d", stripe: "#ffe66d", rail: "#7a1832" },
  { main: "#26c6da", stripe: "#fff3b0", rail: "#075f73" },
  { main: "#7c4dff", stripe: "#ffb74d", rail: "#32116f" },
  { main: "#00c853", stripe: "#f8f4ff", rail: "#076638" },
  { main: "#ff8a00", stripe: "#39d5ff", rail: "#8a3d00" },
];

bestEl.textContent = best;
usernameInput.value = playerName;
setPlayerStatus(playerName ? `Playing as ${playerName}` : "Pick a username before your next run.");

function resetGame() {
  score = 0;
  scoreEl.textContent = score;
  pipes = [];
  snacks = [];
  pawBursts = [];
  spawnTimer = 0;
  frameTime = 0;
  runTime = 0;
  pug.y = 310;
  pug.vy = 0;
  pug.rotation = 0;
  seedClouds();
  spawnPipe(W + 420);
}

function difficulty() {
  return Math.min(1, runTime / 52 + score / 34);
}

function currentPipeSpeed() {
  return physics.pipeSpeed + difficulty() * 48;
}

function currentPipeGap() {
  return physics.pipeGap - difficulty() * 34;
}

function currentSpawnInterval() {
  return 2.65 - difficulty() * 0.9;
}

function seedClouds() {
  clouds = Array.from({ length: 7 }, (_, i) => ({
    x: i * 96 + Math.random() * 70,
    y: 62 + Math.random() * 182,
    s: 0.65 + Math.random() * 0.9,
  }));
}

function setOverlay(visible, title, message, buttonLabel = "Start") {
  overlay.classList.toggle("is-hidden", !visible);
  overlay.querySelector("h1").textContent = title;
  messageEl.textContent = message;
  startBtn.textContent = buttonLabel;
}

function startGame() {
  resetGame();
  state = "playing";
  setOverlay(false);
  flap();
}

function restartGame() {
  startGame();
}

function togglePause() {
  if (state === "playing") {
    state = "paused";
    pauseBtn.textContent = "Resume";
    pauseBtn.setAttribute("aria-label", "Resume game");
    setOverlay(true, "Paused", "Take a breath. The pug is holding position.", "Resume");
  } else if (state === "paused") {
    state = "playing";
    pauseBtn.textContent = "Pause";
    pauseBtn.setAttribute("aria-label", "Pause game");
    setOverlay(false);
  }
}

function flap() {
  if (state === "ready" || state === "ended") {
    startGame();
    return;
  }

  if (state === "paused") {
    togglePause();
    return;
  }

  pug.vy = physics.flap;
  for (let i = 0; i < 5; i++) {
    pawBursts.push({
      x: pug.x - 18 + Math.random() * 16,
      y: pug.y + 17 + Math.random() * 14,
      vx: -50 - Math.random() * 90,
      vy: 10 - Math.random() * 60,
      life: 0.35,
    });
  }
}

function spawnPipe(startX = W + 24) {
  const margin = 92;
  const gap = currentPipeGap();
  const topMax = H - groundH - gap - margin;
  const gapY = margin + Math.random() * Math.max(1, topMax - margin);
  const palette = surfboardPalettes[Math.floor(Math.random() * surfboardPalettes.length)];

  pipes.push({
    x: startX,
    gapY,
    gap,
    palette,
    passed: false,
  });

  snacks.push({
    x: startX + physics.pipeWidth / 2,
    y: gapY + gap / 2,
    spin: Math.random() * Math.PI,
    collected: false,
  });
}

function update(dt) {
  frameTime += dt;

  if (state !== "playing") {
    draw();
    return;
  }

  runTime += dt;
  spawnTimer += dt;
  if (spawnTimer > currentSpawnInterval()) {
    spawnTimer = 0;
    spawnPipe();
  }

  pug.vy += physics.gravity * dt;
  pug.y += pug.vy * dt;
  pug.rotation = Math.max(-0.55, Math.min(0.85, pug.vy / 760));

  clouds.forEach((cloud) => {
    cloud.x -= 18 * cloud.s * dt;
    if (cloud.x < -90) {
      cloud.x = W + 60;
      cloud.y = 50 + Math.random() * 210;
      cloud.s = 0.65 + Math.random() * 0.9;
    }
  });

  pipes.forEach((pipe) => {
    pipe.x -= currentPipeSpeed() * dt;

    if (!pipe.passed && pipe.x + physics.pipeWidth < pug.x - pug.r) {
      pipe.passed = true;
      score += 1;
      scoreEl.textContent = score;
    }
  });

  snacks.forEach((snack) => {
    snack.x -= currentPipeSpeed() * dt;
    snack.spin += dt * 5;
    if (!snack.collected && distance(pug.x, pug.y, snack.x, snack.y) < 34) {
      snack.collected = true;
      score += 2;
      scoreEl.textContent = score;
      for (let i = 0; i < 10; i++) {
        pawBursts.push({
          x: snack.x,
          y: snack.y,
          vx: -130 + Math.random() * 260,
          vy: -160 + Math.random() * 160,
          life: 0.52,
        });
      }
    }
  });

  pawBursts.forEach((paw) => {
    paw.life -= dt;
    paw.x += paw.vx * dt;
    paw.y += paw.vy * dt;
    paw.vy += 220 * dt;
  });

  pipes = pipes.filter((pipe) => pipe.x > -physics.pipeWidth - 30);
  snacks = snacks.filter((snack) => snack.x > -40 && !snack.collected);
  pawBursts = pawBursts.filter((paw) => paw.life > 0);

  if (pug.y + pug.r > H - groundH || pug.y - pug.r < 0 || hitsPipe()) {
    endGame();
  }

  draw();
}

function endGame() {
  state = "ended";
  best = Math.max(best, score);
  localStorage.setItem(storageKey, best);
  bestEl.textContent = best;
  pauseBtn.textContent = "Pause";
  pauseBtn.setAttribute("aria-label", "Pause game");
  setOverlay(true, "Game Over", `Score ${score}. Press Space, click, or tap to try again.`, "Retry");
  submitScore(score);
}

function sanitizeUsername(value) {
  return String(value || "")
    .trim()
    .replace(/[^\w -]/g, "")
    .replace(/\s+/g, " ")
    .slice(0, 18);
}

function setPlayerStatus(message) {
  playerStatus.textContent = message;
}

function saveUsername(value) {
  const clean = sanitizeUsername(value);
  if (!clean) {
    setPlayerStatus("Use 1-18 letters, numbers, spaces, _ or -.");
    return false;
  }

  playerName = clean;
  usernameInput.value = clean;
  localStorage.setItem(usernameKey, clean);
  setPlayerStatus(`Playing as ${clean}`);
  return true;
}

function renderLeaderboard(scores) {
  leaderboardEl.replaceChildren();

  if (!scores.length) {
    const empty = document.createElement("li");
    empty.className = "empty-board";
    empty.textContent = "No scores yet.";
    leaderboardEl.append(empty);
    return;
  }

  scores.forEach((entry, index) => {
    const item = document.createElement("li");
    const rank = document.createElement("span");
    const name = document.createElement("span");
    const points = document.createElement("span");

    rank.className = "rank";
    name.className = "player-name";
    points.className = "player-score";
    rank.textContent = `#${index + 1}`;
    name.textContent = entry.username;
    points.textContent = entry.score;

    item.append(rank, name, points);
    leaderboardEl.append(item);
  });
}

async function loadLeaderboard() {
  try {
    const response = await fetch("/api/leaderboard", { cache: "no-store" });
    if (!response.ok) throw new Error("Leaderboard request failed");
    const data = await response.json();
    renderLeaderboard(Array.isArray(data.scores) ? data.scores : []);
  } catch (error) {
    leaderboardEl.replaceChildren();
    const item = document.createElement("li");
    item.className = "empty-board";
    item.textContent = "Leaderboard unavailable.";
    leaderboardEl.append(item);
  }
}

async function submitScore(finalScore) {
  if (!playerName) {
    setPlayerStatus("Add a username to join the leaderboard.");
    return;
  }

  try {
    const response = await fetch("/api/score", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: playerName, score: finalScore }),
    });

    if (!response.ok) throw new Error("Score request failed");
    const data = await response.json();
    renderLeaderboard(Array.isArray(data.scores) ? data.scores : []);
    setPlayerStatus(`Score ${finalScore} submitted as ${playerName}.`);
  } catch (error) {
    setPlayerStatus("Score could not be submitted.");
  }
}

function hitsPipe() {
  return pipes.some((pipe) => {
    const collisionW = physics.pipeWidth * 0.68;
    const collisionX = pipe.x + (physics.pipeWidth - collisionW) / 2;
    const pugHitR = pug.r * 0.66;
    const inX = pug.x + pugHitR > collisionX && pug.x - pugHitR < collisionX + collisionW;
    if (!inX) return false;
    const inGap = pug.y - pugHitR > pipe.gapY + 8 && pug.y + pugHitR < pipe.gapY + pipe.gap - 8;
    return !inGap;
  });
}

function draw() {
  drawSky();
  drawClouds();
  pipes.forEach(drawPipe);
  snacks.forEach(drawSnack);
  drawOcean();
  pawBursts.forEach(drawPaw);
  drawPug();
}

function drawSky() {
  const gradient = ctx.createLinearGradient(0, 0, 0, H);
  gradient.addColorStop(0, "#6046a6");
  gradient.addColorStop(0.32, "#ff7e67");
  gradient.addColorStop(0.62, "#ffc56e");
  gradient.addColorStop(1, "#1596b5");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, W, H);

  const sunX = W * 0.72;
  const sunY = H * 0.34;
  const glow = ctx.createRadialGradient(sunX, sunY, 8, sunX, sunY, 150);
  glow.addColorStop(0, "rgba(255, 246, 183, 0.92)");
  glow.addColorStop(0.34, "rgba(255, 171, 94, 0.44)");
  glow.addColorStop(1, "rgba(255, 171, 94, 0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);

  ctx.fillStyle = "#ffeaa6";
  ctx.beginPath();
  ctx.arc(sunX, sunY, 48, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "rgba(255, 255, 255, 0.2)";
  for (let y = sunY - 26; y < sunY + 38; y += 15) {
    ctx.fillRect(sunX - 58, y, 116, 5);
  }

  ctx.fillStyle = "rgba(255,255,255,0.25)";
  for (let x = -40; x < W + 80; x += 78) {
    ctx.beginPath();
    ctx.arc(x + Math.sin(frameTime + x) * 4, 382 + Math.cos(frameTime * 0.6 + x) * 6, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  drawWaveBand(420, 26, 0.5, "#1eb5cf", "rgba(255, 244, 214, 0.52)");
  drawWaveBand(462, 32, 0.78, "#118bb4", "rgba(255, 255, 255, 0.42)");
}

function drawClouds() {
  clouds.forEach((cloud) => {
    ctx.save();
    ctx.translate(cloud.x, cloud.y);
    ctx.scale(cloud.s, cloud.s);
    ctx.fillStyle = "rgba(255,255,255,0.82)";
    ctx.beginPath();
    ctx.arc(0, 20, 20, 0, Math.PI * 2);
    ctx.arc(24, 10, 26, 0, Math.PI * 2);
    ctx.arc(54, 21, 20, 0, Math.PI * 2);
    ctx.fillRect(0, 20, 58, 21);
    ctx.fill();
    ctx.restore();
  });
}

function drawPipe(pipe) {
  const w = physics.pipeWidth;
  const boardW = w * 0.76;
  const x = pipe.x + (w - boardW) / 2;
  const bottomY = pipe.gapY + pipe.gap;
  drawSurfboard(x, -38, boardW, pipe.gapY + 52, pipe.palette, true);
  drawSurfboard(x, bottomY - 14, boardW, H - groundH - bottomY + 58, pipe.palette, false);
}

function drawSnack(snack) {
  ctx.save();
  ctx.translate(snack.x, snack.y);
  ctx.rotate(snack.spin);
  ctx.fillStyle = "#7c442f";
  ctx.strokeStyle = "#38211b";
  ctx.lineWidth = 3;
  roundedRect(-17, -12, 34, 24, 10);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#f5c77a";
  ctx.beginPath();
  ctx.arc(-7, -2, 3, 0, Math.PI * 2);
  ctx.arc(7, 4, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawOcean() {
  const y = H - groundH;
  const ocean = ctx.createLinearGradient(0, y - 24, 0, H);
  ocean.addColorStop(0, "#15a9c9");
  ocean.addColorStop(0.55, "#087eaa");
  ocean.addColorStop(1, "#07537c");
  ctx.fillStyle = ocean;
  ctx.fillRect(0, y, W, groundH);

  drawWaveBand(y + 4, 16, 1.05, "#15a9c9", "rgba(255, 255, 255, 0.74)");
  drawWaveBand(y + 35, 18, 1.35, "#087eaa", "rgba(255, 255, 255, 0.48)");

  ctx.fillStyle = "rgba(255, 196, 99, 0.22)";
  for (let x = -40; x < W + 60; x += 42) {
    const offset = (frameTime * currentPipeSpeed() * 0.22) % 42;
    ctx.fillRect(x - offset, y + 68 + Math.sin(frameTime * 2 + x) * 4, 24, 3);
  }
}

function drawSurfboard(x, y, w, h, palette, flip) {
  ctx.save();
  ctx.translate(x + w / 2, y + h / 2);
  ctx.scale(1, flip ? -1 : 1);

  const boardGradient = ctx.createLinearGradient(-w / 2, 0, w / 2, 0);
  boardGradient.addColorStop(0, palette.rail);
  boardGradient.addColorStop(0.18, palette.main);
  boardGradient.addColorStop(0.5, "#fffaf0");
  boardGradient.addColorStop(0.82, palette.main);
  boardGradient.addColorStop(1, palette.rail);

  ctx.fillStyle = boardGradient;
  ctx.strokeStyle = "#35201d";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(0, -h / 2);
  ctx.bezierCurveTo(w * 0.58, -h * 0.34, w * 0.56, h * 0.32, 0, h / 2);
  ctx.bezierCurveTo(-w * 0.56, h * 0.32, -w * 0.58, -h * 0.34, 0, -h / 2);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  ctx.strokeStyle = palette.stripe;
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(0, -h * 0.38);
  ctx.lineTo(0, h * 0.38);
  ctx.stroke();

  ctx.strokeStyle = "rgba(255, 255, 255, 0.65)";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-w * 0.22, -h * 0.3);
  ctx.bezierCurveTo(-w * 0.34, -h * 0.06, -w * 0.32, h * 0.17, -w * 0.12, h * 0.34);
  ctx.stroke();

  ctx.fillStyle = "rgba(53, 32, 29, 0.18)";
  ctx.beginPath();
  ctx.ellipse(0, h * 0.26, w * 0.22, 9, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawWaveBand(baseY, amplitude, speed, waterColor, foamColor) {
  const offset = (frameTime * currentPipeSpeed() * speed) % 96;

  ctx.fillStyle = waterColor;
  ctx.beginPath();
  ctx.moveTo(0, H);
  ctx.lineTo(0, baseY);
  for (let x = -96; x <= W + 96; x += 24) {
    const y = baseY + Math.sin((x - offset) * 0.035) * amplitude + Math.sin((x - offset) * 0.078) * amplitude * 0.35;
    ctx.lineTo(x, y);
  }
  ctx.lineTo(W, H);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = foamColor;
  ctx.lineWidth = 4;
  ctx.beginPath();
  for (let x = -96; x <= W + 96; x += 18) {
    const y = baseY + Math.sin((x - offset) * 0.035) * amplitude + Math.sin((x - offset) * 0.078) * amplitude * 0.35;
    if (x === -96) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
  }
  ctx.stroke();
}

function drawPaw(paw) {
  ctx.save();
  ctx.globalAlpha = Math.max(0, paw.life * 2);
  ctx.fillStyle = "#fff2d0";
  ctx.translate(paw.x, paw.y);
  ctx.beginPath();
  ctx.arc(0, 3, 5, 0, Math.PI * 2);
  ctx.arc(-5, -4, 3, 0, Math.PI * 2);
  ctx.arc(0, -6, 3, 0, Math.PI * 2);
  ctx.arc(5, -4, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawPug() {
  ctx.save();
  ctx.translate(pug.x, pug.y);
  ctx.rotate(pug.rotation);
  ctx.scale(0.88, 0.88);

  ctx.fillStyle = "#d6a067";
  ctx.strokeStyle = "#3b2822";
  ctx.lineWidth = 4;

  ctx.beginPath();
  ctx.ellipse(0, 3, 31, 27, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = "#5b4034";
  ctx.beginPath();
  ctx.ellipse(-21, 0, 11, 19, -0.45, 0, Math.PI * 2);
  ctx.ellipse(21, 0, 11, 19, 0.45, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = "#806052";
  ctx.beginPath();
  ctx.ellipse(0, 9, 18, 15, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#1f1917";
  ctx.beginPath();
  ctx.arc(-10, -5, 4, 0, Math.PI * 2);
  ctx.arc(10, -5, 4, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#251917";
  ctx.beginPath();
  ctx.ellipse(0, 6, 7, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "#251917";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(0, 9);
  ctx.quadraticCurveTo(-7, 15, -14, 12);
  ctx.moveTo(0, 9);
  ctx.quadraticCurveTo(7, 15, 14, 12);
  ctx.stroke();

  ctx.fillStyle = "#f3d6be";
  ctx.beginPath();
  ctx.ellipse(10, 15, 5, 8, -0.4, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#fff7df";
  ctx.beginPath();
  ctx.arc(-11, -7, 1.4, 0, Math.PI * 2);
  ctx.arc(9, -7, 1.4, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "#3b2822";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(30, 10, 12, -1.1, 1.5);
  ctx.stroke();

  ctx.restore();
}

function roundedRect(x, y, w, h, r) {
  const radius = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

function distance(x1, y1, x2, y2) {
  return Math.hypot(x1 - x2, y1 - y2);
}

function loop(time = 0) {
  const dt = Math.min(0.033, (time - lastTime) / 1000 || 0);
  lastTime = time;
  update(dt);
  requestAnimationFrame(loop);
}

startBtn.addEventListener("click", flap);
pauseBtn.addEventListener("click", togglePause);
restartBtn.addEventListener("click", restartGame);
canvas.addEventListener("pointerdown", flap);
refreshBoardBtn.addEventListener("click", loadLeaderboard);

playerForm.addEventListener("submit", (event) => {
  event.preventDefault();
  saveUsername(usernameInput.value);
});

window.addEventListener("keydown", (event) => {
  if (event.code === "Space" || event.code === "ArrowUp") {
    event.preventDefault();
    flap();
  }

  if (event.code === "KeyP") {
    togglePause();
  }

  if (event.code === "KeyR") {
    restartGame();
  }
});

resetGame();
setOverlay(true, "Flappy Pug", "Press Space, click, or tap to help the pug fly through the treats.", "Start");
loadLeaderboard();
requestAnimationFrame(loop);
